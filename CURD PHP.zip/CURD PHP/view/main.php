<body>
       <div class ="khung">
         <center><h2>Bài Làm Giữa Kì</h2></center>
         <div class="the1">
         <h4>Họ Và Tên :</h4> <p class="hoten">Phạm Văn Nam</p>
         </div> 
         <div class="the1">
         <h4>Lớp :</h4> <p class="lop1">21AD</p>
         </div> 
         <div class="the1 te">
         <h4>Mã Sinh Viên :</h4> <p class="lop">21AD040</p>
         </div> 
         <div class="tsv"> 
         <a href="bailam?act=bailam">Bài Làm Của Sinh Viên</a>
         <i class="fa fa-address-book" aria-hidden="true"></i>
         </div>
        
        </div>
</body>